// $(window).scroll(function() {
//     var scroll = $(window).scrollTop();
//     if (scroll >= 250) {
//         $(".header-outer").addClass("fixed-header animated slideInDown");
//     } else {
//     	$(".header-outer").removeClass("fixed-header animated slideInDown");
//     }
//     if ($(window).width() < 1024) {
//         $(".header-outer").removeClass('fixed-header animated slideInDown');
//     }    
// });

$(window).load(function () {
    $(".preloader").fadeOut(function () {
     // $(".centerLogo").addClass('show-logo');
    });
});



(function($) {
  $.fn.menumaker = function(options) {  
    var mainMenus = $(this), settings = $.extend({
      format: "dropdown",
      sticky: false
    }, options);
    return this.each(function() {
      $(this).find(".mobileMenu").on('click', function(){
        $(this).toggleClass('menu-opened');
        var mainmenu = $(this).next('ul');
        if (mainmenu.hasClass('open')) { 
          mainmenu.slideToggle().removeClass('open');
        }
        else {
          mainmenu.slideToggle().addClass('open');
          if (settings.format === "dropdown") {
            mainmenu.find('ul').show();
          }
        }
      });
      mainMenus.find('li ul').parent().addClass('has-sub');
  multiTg = function() {
      mainMenus.find(".has-sub").prepend('<span class="submenu-button"></span>');
      mainMenus.find('.submenu-button').on('click', function() {
          $(this).toggleClass('submenu-opened');
          if ($(this).siblings('ul').hasClass('open')) {
            $(this).siblings('ul').removeClass('open').slideToggle();
          }
          else {
            $(this).siblings('ul').addClass('open').slideToggle();
          }
        });
      };
      if (settings.format === 'multitoggle') multiTg();
      else mainMenus.addClass('dropdown');
      if (settings.sticky === true) mainMenus.css('position', 'fixed');
  resizeFix = function() {
    var mediasize = 1180;
        if ($( window ).width() > mediasize) {
          mainMenus.find('ul').show();
        }
        if ($(window).width() <= mediasize) {
          mainMenus.find('ul').hide().removeClass('open');
        }
      };
      resizeFix();
      return $(window).on('resize', resizeFix);
    });
    };
  })(jQuery);
  
  (function($){
  $(document).ready(function(){
  $("#mainMenus").menumaker({
      format: "multitoggle"
  });
  });
  })(jQuery);
  
   

$(function() {
  jQuery('.achr-tag ul li a:not([href=\\#])').on('click', function() {
      var target = jQuery(this.hash);
      target = target.length ? target : jQuery('[name=' + this.hash.substr(1) +']');
      if (target.length) {
          jQuery('html,body').animate({
              scrollTop: target.offset().top
          }, 1000);
          return false;
      }
  });
});

$(function() {
  jQuery('.footerSec .footerInner .footer_widgets ul li a:not([href=\\#])').on('click', function() {
      var target = jQuery(this.hash);
      target = target.length ? target : jQuery('[name=' + this.hash.substr(1) +']');
      if (target.length) {
          jQuery('html,body').animate({
              scrollTop: target.offset().top
          }, 1000);
          return false;
      }
  });
});


$(window).load(function(){
  // $('.counter').counterUp();
   AOS.init({
      once: true,
      disable: 'mobile'
   });
});